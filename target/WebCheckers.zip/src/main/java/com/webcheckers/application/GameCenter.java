package com.webcheckers.application;

import com.webcheckers.model.Game;

import java.util.HashMap;
import java.util.logging.Logger;

public class GameCenter {

    //declaring the hashmap with key as name of player and value as game object where the player is playing
    private HashMap<String, Game> gameMap;
    private static final Logger LOG = Logger.getLogger(GameCenter.class.getName());

    /**
     * Constructor for Game center
     */
    public GameCenter() {
        gameMap = new HashMap<>();
    }

    /**
     * Add games to the game map with player names as key to the game value in hashmap
     * @param name the name of player playing the game
     * @param game the game being played by the mentioned player
     */
    public void addGame(String name, Game game) {
        gameMap.put(name, game);
        LOG.config(String.format("%s added to a game.", name));
    }

    /**
     * get a game from the game Map that corresponds to the player name
     * @param name the name of the player playing that game
     * @return Game object of which the player is a part of
     */
    public Game getGame(String name) {
        return gameMap.get(name);
    }

    /**
     * remove a name,game pair from the map
     * @param name the name of the player that is the key to be removed
     */
    public void removeGameBoard(String name){
        gameMap.remove(name, getGame(name));
        LOG.config(String.format("%s removed from a game.", name));
    }
}
