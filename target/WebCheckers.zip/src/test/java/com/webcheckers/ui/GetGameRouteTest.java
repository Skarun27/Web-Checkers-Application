package com.webcheckers.ui;

import com.google.gson.Gson;
import com.webcheckers.application.GameCenter;
import com.webcheckers.application.PlayerLobby;
import com.webcheckers.model.BoardView;
import com.webcheckers.model.Game;
import com.webcheckers.model.Piece;
import com.webcheckers.model.Player;
import com.webcheckers.ui.GetGameRoute;
import com.webcheckers.ui.GetHomeRoute;
import com.webcheckers.ui.PostSignInRoute;
import com.webcheckers.ui.WebServer;
import com.webcheckers.util.Message;
import spark.*;

import java.util.*;
import java.util.logging.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
@Tag ("UI-Tier")
/**
 * a route to render the game page
 * invoked by GET /game
 */
public class GetGameRouteTest  {

    private Request request;
    private Response response;
    private Session session;
    private GetGameRoute gameRoute;

    private TemplateEngine templateEngine;
    private PlayerLobby playerLobby;
    private GameCenter gameCenter;
    private Gson gson;

    private Player currentPlayer;
    private Player secondPlayer;
    private Piece.pieceColor activeColor;
    private BoardView board;
    private Game game;

    @BeforeEach
    public void testBuild(){
        request=mock(Request.class);
        response=mock(Response.class);
        session=mock(Session.class);
        when(request.session()).thenReturn(session);

        templateEngine=mock(TemplateEngine.class);
        playerLobby=mock(PlayerLobby.class);
        gameCenter=mock(GameCenter.class);
        gameRoute= new GetGameRoute(templateEngine,playerLobby,gameCenter, gson);
    }

    @Test
    public void redGame() throws Exception {
        currentPlayer=new Player("red");
        secondPlayer=new Player("white");
        activeColor= Piece.pieceColor.RED;
        board=mock(BoardView.class);
//        game=new Game(currentPlayer.getName(),secondPlayer.getName(),activeColor,board, gson);
        when(session.attribute("Player")).thenReturn(currentPlayer);
        when(playerLobby.getPlayer("white")).thenReturn(secondPlayer);
        gameRoute.handle(request,response);

    }
    @Test
    public void whiteGame() throws Exception {
        currentPlayer=new Player("red");
        secondPlayer=new Player("white");
        activeColor= Piece.pieceColor.RED;
        board=mock(BoardView.class);
//        game=new Game(currentPlayer.getName(),secondPlayer.getName(),activeColor,board);
        when(session.attribute("Player")).thenReturn(secondPlayer);
        when(playerLobby.getPlayer("white")).thenReturn(secondPlayer);
        gameRoute.handle(request,response);

    }
    @Test
    public void inGame() throws Exception {
        currentPlayer=new Player(null);
        secondPlayer=new Player("white");
        activeColor= Piece.pieceColor.RED;
        board=mock(BoardView.class);
//        game=new Game(currentPlayer.getName(),secondPlayer.getName(),activeColor,board);
        when(session.attribute(null)).thenReturn(secondPlayer);
        when(playerLobby.getPlayer("white")).thenReturn(secondPlayer);
        gameRoute.handle(request,response);

    }


}
