package com.webcheckers.ui.model;

import com.webcheckers.model.BoardView;
import com.webcheckers.model.Game;
import com.webcheckers.model.Piece;
import static org.junit.jupiter.api.Assertions.*;

import com.webcheckers.util.MoveValidationHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
@Tag("Model-Tier")
/**
 * Operates a game
 * stores board and other data for the game
 */
public class GameTest {

    //attributes
    private String redPlayerName;
    private String whitePlayerName;
    private Piece.pieceColor activeColor;
    private Game game;
    private BoardView board;
    private MoveValidationHelper helper;

    @BeforeEach
    public void testBuild(){
        redPlayerName="Tester";
        whitePlayerName="Opponent";
        activeColor= Piece.pieceColor.RED;
        board=mock(BoardView.class);
        helper=mock(MoveValidationHelper.class);
        game=new Game(board,redPlayerName,whitePlayerName,activeColor,helper);
    }

    @Test
    public void testGet(){
        assertEquals(redPlayerName,game.getRedPlayerName());
        assertEquals(activeColor,game.getActiveColor());
        assertEquals(whitePlayerName,game.getWhitePlayerName());
        BoardView board=game.getBoard();
    }


}
