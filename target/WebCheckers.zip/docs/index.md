# PROJECT Home

Welcome to the PROJECT Project!

## Team

* MEMBER1
* MEMBER2

## [Design Documentation](DesignDoc)

Click above for details of the PROJECT design documentation.

## [Setup Guide](SetupGuide)

Click above for details about how to setup your development environment to work on this project.
